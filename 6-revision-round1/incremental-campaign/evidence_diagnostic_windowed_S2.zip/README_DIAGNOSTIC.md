# Diagnóstico exploratório S2 — perda do aviso cinemático no gate (implementação por janelas)

Conteúdo deste pacote (originais preservados em
`6-revision-round1/incremental-campaign/diagnostic-windowed-S2/` no repositório
do artefato):
- DIAGNOSTIC_PREREG.md — protocolo pré-registrado (escrito antes da execução) e
  registro da sequência de execução/condições A-B;
- DIAGNOSTIC_REPORT.md — relatório com a verificação da cadeia causal;
- windowed_s2.py — código do diagnóstico (implementação fiel de
  tera_infer.py::infer_stream_hybrid em numpy, sem torch);
- incremental_engine.py — dependência local (leitor de checkpoint .pt sem torch
  + LSTM numpy, validado contra os valores publicados);
- s2_windowed_results.csv — resultados por seed/configuração/condição;
- logs_ep_seed{S}_{config}_{cond}.csv (48) — logs por episódio (onset, detecção,
  nº de updates, maior sequência sem update, congelado-até-o-fim, p final);
- logs_gate_seed{S}_{config}_{cond}.csv.gz (48) — decisões do gate por frame
  (dk entregue ao gate, entropia usada, ativação);
- HASHES_DIAGNOSTIC.txt — sha256 de todos os arquivos acima.

## Execução

    python3 windowed_s2.py 42 43 44 45 46 47 48 49 50 51 52 53

Dependências: Python ≥3.10, numpy ≥1.26, pandas ≥2.0. Sem GPU e sem torch.

## Insumos NECESSÁRIOS e não incluídos neste pacote

O script lê, por caminho relativo a partir da raiz do repositório do artefato
(`1-pipeline-tera/results/exp_seed12_round1/`):
- models/{baseline,student}_seed{42..53}.pt (checkpoints congelados);
- data/X_te_seed{S}.npy, y_fr_te_seed{S}.npy, y_ep_te_seed{S}.npy;
- calibration/calibration_summary.csv (limiares publicados por seed).

O diagnóstico é reproduzível COM o repositório completo do artefato (que contém
esses insumos); este pacote isolado NÃO é autossuficiente. A condição A
reproduz os valores publicados por seed (sanidade embutida: diferença de FR
0,000000 e de supressão ≤5e-4 p.p. contra expanded_per_seed.csv).
